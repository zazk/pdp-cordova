var BASE_URL_SERVICE_REST =  'http://app.patadeperroapp.com/pdp-rest/';
var BASE_URL_SERVER_WEB_IMAGES =  'http://app.patadeperroapp.com/pdp/';
var BASE_URL_WEB_PDP =  'http://app.patadeperroapp.com/pdp/';
var ESTADO_ACTIVO = 1;
var ESTADO_INACTIVO = 2;
var CALIDAD_IMG_MEDIA = 30;
